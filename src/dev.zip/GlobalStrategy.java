package dev;

public class GlobalStrategy {
	public static boolean rush = false;

}
